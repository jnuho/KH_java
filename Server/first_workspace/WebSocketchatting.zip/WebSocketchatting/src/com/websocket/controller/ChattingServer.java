package com.websocket.controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import javax.websocket.EncodeException;
import javax.websocket.EndpointConfig;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import common.message.Message;
import common.message.MessageDecoder;
import common.message.MessageEncoder;

@ServerEndpoint(
		value = "/chatting",
		encoders = {MessageEncoder.class},
		decoders = {MessageDecoder.class}
		)
public class ChattingServer {

	//클라이언트가 웹소켓서버에 연결요청을 하면
	//실해되는 매소드
	@OnOpen
	public void open(Session session, 
			EndpointConfig config) {
		System.out.println("접속성공!"+session.getId());
	}
	
	//전송오는 데이터를 받는 매소드 설정
	//@OnMessage
	
	@OnMessage
	public void message(Session session, Message msg) {
		
		System.out.println(msg);
		
		try {
			session.getBasicRemote().sendObject(new Message("admin","접속을 환영합니다.","01","msg",""));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EncodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
//	@OnMessage
//	public void message(Session session,String msg) {
//		System.out.println(msg);
//		//전체 session(연결된 컴퓨터를) 확인하기
//		//sesssion객체에서 연결되어있는 session을 확인할 수 있는
//		//매소드를 제공!
//		//getOpesSessions(); 반환형 Set
//		Set list=session.getOpenSessions();
//		
//		//String메세지를 파싱처리함.
//		String[] msgs=msg.split(",");
//		//for(String s : msgs) {
//			System.out.println(msgs[0]);
//			System.out.println(msgs[1]);
//			System.out.println(msgs[2]);
//			System.out.println(msgs[3]);
//			
//		//}
//		
//		//session에 필요한 데이터 넣기
//		//getUserProperties() : session에 필요한 정보를
//		//저장하는 Map형식의 객체
//		session.getUserProperties().put("userId", msgs[0]);
//		session.getUserProperties().put("msg", msgs[1]);
//		session.getUserProperties().put("room", msgs[2]);
//		session.getUserProperties().put("flag", msgs[3]);
//		session.getUserProperties().put("receiveId", msgs[4]);
//		
//		
//		
//		
//		//클라이언트한테 받은 메세지를 다시 전송
//		//session을 이용해서 각 클라이언트를 구분
//		try {
//			//현재 연결되어있는 전체 session불러오기!
//			for(Session s : session.getOpenSessions()) {
//				String userId=(String)s.getUserProperties().get("userId");
//				String recieveId=(String)s.getUserProperties().get("receiveId");
//				
//				//전체접속회원 보내기
//				sendMember(session);
//				
//				if(userId!=null&&recieveId!=null&&userId.equals(recieveId)) {				
//					s.getBasicRemote().sendText(userId+","+msg+",01,msg");
//				}
//				if(recieveId==null) {
//					s.getBasicRemote().sendText(userId+","+msg+",01,msg");
//				}
//			}
//			
//			//session.getBasicRemote().sendText("관리자 : "+msg);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	
	private void sendMember(Session session) {
		
		String members="";
		for(Session s : session.getOpenSessions()) {
			members+=(String)s.getUserProperties().get("userId")+"§";
		}
		
		try {
			session.getBasicRemote()
			.sendText("admin,"+members+",01,members");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@OnMessage(
			maxMessageSize = 1024*1024*100)
	public void message(ByteBuffer data, Session session) {
		System.out.println("데이터 전송했니?");
		System.out.println(data);
		System.out.println(session);
		
		try(BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("d:\\file"));) {
			bos.write(data.array());
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	
	
}




